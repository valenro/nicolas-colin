import requests
import pandas as pd  
import psycopg2 
from psycopg2.extras import execute_values
def insert_covid_tracker():


  response = requests.get('https://api.covidtracking.com/v1/us/daily.json')

  #Llamada a la api Devuelve track de casos de covid


  if response.status_code == 200:
    
      data = response.json() 
      df = pd.DataFrame(data)
      df.drop_duplicates()
      df.fillna(0, inplace=True)
      df['dateChecked'] = df['dateChecked'].str.replace('T24:00:00Z', 'T00:00:00Z')
      df['dateChecked'] = pd.to_datetime(df['dateChecked'])
      #Conexion a la base de datos
      host='data-engineer-cluster.cyhh5bfevlmn.us-east-1.redshift.amazonaws.com'
      port = 5439
      database = 'data-engineer-database'
      user = 'nicolas_colin_coderhouse'
      password = 'z8DQci168V'
      try:
        #Establezco la conexion a redshift
        conn = psycopg2.connect(
            host=host,
            port=port,
            dbname=database,
            user=user,
            password=password
        )
          
        cursor = conn.cursor()
        # Borro los datos 
        sSql="DELETE FROM  nicolas_colin_coderhouse.COVID_TRACKER"
        cursor.execute(sSql)
        sSql="" 
        sSql = f"INSERT INTO nicolas_colin_coderhouse.COVID_TRACKER(datePublish,state,positive,negative,pending,hospitalizedCurrently,hospitalizedCumulative,inIcuCurrently,inIcuCumulative,onVentilatorCurrently,onVentilatorCumulative,dateChecked,death,hospitalized,totalTestResults,lastModified,recovered,total,posNeg,deathIncrease,hospitalizedIncrease,negativeIncrease,positiveIncrease,totalTestResultsIncrease,hash) VALUES %s"
        sValues = [tuple(row) for row in df.to_numpy()]
        execute_values(cursor, sSql, sValues)
        # Persisto los datos en la BD  
        conn.commit()
        # Cierro las conexiones y el cursor 
        cursor.close()
        conn.close()
      except psycopg2.Error as e:
          print("Error al conectar a Redshift:", e)
  else:
      # La solicitud no fue exitosa
      print('Error al hacer la solicitud:', response.status_code)

