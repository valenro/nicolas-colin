from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from etl_covid_tracker import insert_covid_tracker
default_args={
    'owner': 'NicolasC',
    'retries':5,
    'retry_delay': timedelta(minutes=5)
}

with DAG(
    default_args=default_args,
    dag_id='covid_tracker',
    description= 'Covid Track',
    start_date=datetime(2023,8,26,2),
    schedule_interval='@daily'
    ) as dag:
    task1= PythonOperator(
        task_id='covid_track',
        python_callable= insert_covid_tracker,
    )

    task1