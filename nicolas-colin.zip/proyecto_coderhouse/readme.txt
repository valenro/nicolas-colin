Pasos a seguir para la instalacion de mi DAG de apache_airflow 

1 - Abrir Docker Desktop
2 - Crear un directorio llamado airflow_docker 
3 - Copiar el archivo  docker-compose.yaml dentro del directorio airflow_docker
4 - Copiar los directorios dags, plugins, logs, input_files,output_files,config
5 - Abrir una ventana de comandos o de powershell ir al directorio airflow_docker 
6 - Ejecutar el comando docker-compose up para levantar apache_airflow 
7 - Activar el Dag 
8 - El Dag está programado para que se ejeucte diariamente a las 00:00 

